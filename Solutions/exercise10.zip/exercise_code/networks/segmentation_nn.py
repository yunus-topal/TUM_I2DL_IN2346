"""SegmentationNN"""
import torch
import torch.nn as nn
import pytorch_lightning as pl
import numpy as np
import torch.nn.functional as F
from torchvision.models import resnet50

class SegmentationNN(nn.Module):

    def __init__(self, num_classes=23, hparams=None):
        super().__init__()
        #######################################################################
        #                             YOUR CODE                               #
        #######################################################################
        
        #first attempt
        #self.conv1 = nn.Conv2d(in_channels=3, out_channels=12, kernel_size=3, stride=1, padding=1)
        #self.pool1 = nn.MaxPool2d(kernel_size=3)
        #self.conv2 = nn.Conv2d(in_channels=12, out_channels=12, kernel_size=3, stride=1, padding=1)
        #self.pool2 = nn.MaxPool2d(kernel_size=4)
        ### upsampling
        model_ft = resnet50(pretrained=True)
        ### strip the last layer
        self.model = torch.nn.Sequential(*list(model_ft.children())[:6])
        self.up1 = nn.Upsample(scale_factor=2, mode='bilinear')
        self.tconv1 = nn.Conv2d(in_channels=512, out_channels=256, kernel_size=3, stride=1, padding=1)
        self.bn1 = nn.BatchNorm2d(256, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        self.up2 = nn.Upsample(scale_factor=2, mode='bilinear')
        self.tconv2 = nn.Conv2d(in_channels=256, out_channels=128, kernel_size=3, stride=1, padding=1)
        self.bn2 = nn.BatchNorm2d(128, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)
        self.up3 = nn.Upsample(scale_factor=2, mode='bilinear')
        self.tconv3 = nn.Conv2d(in_channels=128, out_channels=23, kernel_size=1, stride=1, padding=0)
        self.bn3 = nn.BatchNorm2d(23, eps=1e-05, momentum=0.1, affine=True, track_running_stats=True)

        #######################################################################
        #                           END OF YOUR CODE                          #
        #######################################################################

    def forward(self, x):
        """
        Forward pass of the convolutional neural network. Should not be called
        manually but by calling a model instance directly.

        Inputs:
        - x: PyTorch input Variable
        """
        #######################################################################
        #                             YOUR CODE                               #
        #######################################################################
        
        #first attempt
        

        for param in self.model.parameters():
          param.requires_grad = True 
        x = self.model(x)
        # print(np.shape(x))
        # upsample by 5, 3, 2
        #x = self.pool1(F.relu(self.conv1(x)))
        #x = self.pool2(F.relu(self.conv2(x))) 
        x = F.relu(self.bn1(self.tconv1(self.up1(x))))
        x = F.relu(self.bn2(self.tconv2(self.up2(x))))
        x = F.relu(self.bn3(self.tconv3(self.up3(x))  )) 
        #######################################################################
        #                           END OF YOUR CODE                          #
        #######################################################################

        return x

    @property
    def is_cuda(self):
        """
        Check if model parameters are allocated on the GPU.
        """
        return next(self.parameters()).is_cuda

    def save(self, path):
        """
        Save model with its parameters to the given path. Conventionally the
        path should end with "*.model".

        Inputs:
        - path: path string
        """
        print('Saving model... %s' % path)
        torch.save(self, path)

        
class DummySegmentationModel(pl.LightningModule):

    def __init__(self, target_image):
        super().__init__()
        def _to_one_hot(y, num_classes):
            scatter_dim = len(y.size())
            y_tensor = y.view(*y.size(), -1)
            zeros = torch.zeros(*y.size(), num_classes, dtype=y.dtype)

            return zeros.scatter(scatter_dim, y_tensor, 1)

        target_image[target_image == -1] = 1

        self.prediction = _to_one_hot(target_image, 23).permute(2, 0, 1).unsqueeze(0)

    def forward(self, x):
        return self.prediction.float()
